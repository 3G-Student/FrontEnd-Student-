import { useState } from "react";
import './admin.css';
import Sidebar from "../../components/adminComponents/SideBar";
import StatsBar from '../../components/adminComponents/StatsBar';
import RegisterTeacher from '../../components/adminComponents/RegisterTeacher';
import TeacherProfile from '../../components/adminComponents/TeacherProfile';
import TeacherList from '../../components/adminComponents/TeacherList';
import Logo from "../../assets/logo.svg";
import Notification from "../../components/adminComponents/Notification";

const initialTeachers = [
  { id: '024567', name: 'Jorge Munhoz', email: 'jorge@email.com', avatar: 'https://cdn.codia.ai/figma/6DAspzy5AqWCvWiZgFCcbv/img-5df6a5cd6ba7f533.svg' },
  { id: '984901', name: 'Joaquim Carvalho', email: 'joaquim@email.com', avatar: 'https://cdn.codia.ai/figma/6DAspzy5AqWCvWiZgFCcbv/img-1c77ba721802b5e0.svg' },
];

export default function App() {

  const [teachers, setTeachers] = useState(initialTeachers);
  const [selectedTeacher, setSelectedTeacher] = useState(null);
  const [notification, setNotification] = useState({
    message: "",
    type: ""
  });

  const showNotification = (message, type) => {
    setNotification({ message, type });
  };

  const handleRegister = (newTeacher) => {
    setTeachers([...teachers, newTeacher]);
  };

  const handleDelete = (id) => {
    const filtered = teachers.filter(t => t.id !== id);
    setTeachers(filtered);
    setSelectedTeacher(null);
  };

  return (
    <div className="app-root">
      <Sidebar />

      <Notification 
        message={notification.message}
        type={notification.type}
        onClose={() => setNotification({ message: "", type: "" })}
      />

      <main className="main-content">
        <header className="main-header">
          <div>
            <h1 className="header-title">Home</h1>
            <p className="header-subtitle">Secretaria</p>
          </div>
          <img className="logo-student" src={Logo} />
        </header>

        <div className="content-area">
          <div className="left-panel">
            <StatsBar />

            <RegisterTeacher 
              onRegister={handleRegister}
              showNotification={showNotification}
            />
            <TeacherProfile 
              teacher={selectedTeacher}
              onDelete={handleDelete}
            />
          </div>

          <div className="right-panel">
            <TeacherList 
              teachers={teachers}
              onSelect={setSelectedTeacher}
            />
          </div>
        </div>
      </main>
    </div>
  );
}


// const API = "http://localhost:8080/professor";

// export default function App() {

//   const [teachers, setTeachers] = useState([]);
//   const [selectedTeacher, setSelectedTeacher] = useState(null);

//   // 🔹 Buscar professores
//   useEffect(() => {
//     fetch(`${API}/listar`)
//       .then(res => res.json())
//       .then(data => setTeachers(data))
//       .catch(err => console.error("Erro ao buscar professores:", err));
//   }, []);

//   // 🔹 Cadastrar professor
//   const handleRegister = async (teacherData) => {
//     await fetch(`${API}/cadastrar`, {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json"
//       },
//       body: JSON.stringify(teacherData)
//     });

//     // Atualiza lista após cadastrar
//     const response = await fetch(`${API}/listar`);
//     const data = await response.json();
//     setTeachers(data);
//   };

//   // 🔹 Remover professor
//   const handleDelete = async (id) => {
//     await fetch(`${API}/excluir/${id}`, {
//       method: "DELETE"
//     });

//     setTeachers(teachers.filter(t => t.idProfessor !== id));
//     setSelectedTeacher(null);
//   };

//   return (
//     <div className="app-root">
//       <Sidebar />

//       <main className="main-content">
//         <header className="main-header">
//           <div>
//             <h1 className="header-title">Home</h1>
//             <p className="header-subtitle">Secretaria</p>
//           </div>
//           <img className="logo-student" src={Logo} />
//         </header>

//         <div className="content-area">
//           <div className="left-panel">
//             <StatsBar />

//             <RegisterTeacher onRegister={handleRegister} />

//             <TeacherProfile 
//               teacher={selectedTeacher}
//               onDelete={handleDelete}
//             />
//           </div>

//           <div className="right-panel">
//             <TeacherList 
//               teachers={teachers}
//               onSelect={setSelectedTeacher}
//             />
//           </div>
//         </div>
//       </main>
//     </div>
//   );
// }