import './aluno.css';
import Logo from "../../assets/logo.svg";
import Sidebar from "../../components/adminComponents/SideBar";


const GRADES = [
  { subject: "Matemática", n1: "7.5", n2: "7.5", final: "7.5" },
  { subject: "Português",  n1: "7.5", n2: "7.5", final: "7.5" },
  { subject: "História",   n1: "7.5", n2: "7.5", final: "7.5" },
  { subject: "Ciências",   n1: "7.5", n2: "7.5", final: "7.5" },
  { subject: "Informática",n1: "7.5", n2: "7.5", final: "7.5" },
];

const NOTIFICATIONS = [
  {
    id: 1,
    name: "Catarina Mendes da Costa",
    subtitle: "Enviou uma observação",
    text: "Olá! O conteúdo da recuperação será disponibilizado na próxima aula. Tenham um bom dia.",
  },
  {
    id: 2,
    name: "Catarina Mendes da Costa",
    subtitle: "Enviou uma observação",
    text: "Obrigada por avisar. Irei agendar a prova assim que eu verificar o número de alunos que precisarão realizar também.",
  },
  {
    id: 3,
    name: "Catarina Mendes da Costa",
    subtitle: "Enviou uma observação",
    text: "Olá. Os slides da aula de hoje já foram disponibilizados. Não se esqueça que nossa prova foi marcada para a próxima semana. Estude bastante e tenha um ótimo final de semana! Boa sorte.",
  },
];

function GradesTable() {
  return (
    <div className="grades-card">
      <table className="grades-table">
        <thead>
          <tr>
            <th>Matéria</th>
            <th>N1</th>
            <th>N2</th>
            <th>Média Final</th>
          </tr>
        </thead>
        <tbody>
          {GRADES.map((row) => (
            <tr key={row.subject}>
              <td>{row.subject}</td>
              <td>{row.n1}</td>
              <td>{row.n2}</td>
              <td>{row.final}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function NotifCard({ notif }) {
  return (
    <div className="notif-card">
      <img
        src={notif.avatar}
        alt={notif.name}
        className="notif-avatar"
      />
      <div className="notif-body">
        <div className="notif-name">{notif.name}</div>
        <div className="notif-subtitle">{notif.subtitle}</div>
        <div className="notif-text">{notif.text}</div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <div className="dashboard">
      {/* Purple sidebar */}
     <Sidebar />

      {/* Main area */}
      <div className="main-content">
        {/* Top nav */}
        <div className="topnav">
          <div className="topnav-left">
            <span className="topnav-home">Home</span>
            <span className="topnav-breadcrumb">Aluno</span>
          </div>
          <img className="logo-student" src={Logo} />
          
        </div>

        {/* Page heading */}
        <div className="page-heading">
          <h1 className="student-name">João Silva</h1>
          <h2 className="notifications-title">Minhas notificações</h2>
        </div>

        {/* Two-column body */}
        <div className="body-columns">
          {/* Boletim */}
          <div className="boletim-card">
            <h2 className="boletim-title">Boletim</h2>
            <GradesTable />
          </div>

          {/* Notifications */}
          <div className="notifications-col">
            <div className="notifications-list">
              {NOTIFICATIONS.map((notif) => (
                <NotifCard key={notif.id} notif={notif} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}


// import { useEffect, useState } from "react";
// import './aluno.css';
// import Logo from "../../assets/logo.svg";
// import Sidebar from "../../components/adminComponents/SideBar";

// const API_ALUNO = "http://localhost:8080/aluno";
// const API_OBS = "http://localhost:8080/observacao";
// const API_BOLETIM = "http://localhost:8080/boletim";

// export default function App() {

//   const alunoId = 1; // depois você pode pegar do login

//   const [aluno, setAluno] = useState(null);
//   const [grades, setGrades] = useState([]);
//   const [notifications, setNotifications] = useState([]);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     async function fetchData() {
//       try {

//         const alunoRes = await fetch(`${API_ALUNO}/buscarPorId/${alunoId}`);
//         const alunoData = await alunoRes.json();

//         const obsRes = await fetch(`${API_OBS}/buscarObservacoesPorIdAluno/${alunoId}`);
//         const obsData = await obsRes.json();

//         const boletimRes = await fetch(`${API_BOLETIM}/buscarPorAluno/${alunoId}`);
//         const boletimData = await boletimRes.json();

//         setAluno(alunoData);
//         setNotifications(obsData);
//         setGrades(boletimData);

//       } catch (error) {
//         console.error("Erro ao buscar dados:", error);
//       } finally {
//         setLoading(false);
//       }
//     }

//     fetchData();
//   }, []);

//   return (
//     <div className="dashboard">
//       <Sidebar />

//       <div className="main-content">

//         <div className="topnav">
//           <div className="topnav-left">
//             <span className="topnav-home">Home</span>
//             <span className="topnav-breadcrumb">Aluno</span>
//           </div>
//           <img className="logo-student" src={Logo} />
//         </div>

//         {loading ? (
//           <p style={{ padding: "20px" }}>Carregando informações...</p>
//         ) : (
//           <>
//             <div className="page-heading">
//               <h1 className="student-name">
//                 {aluno?.nome}
//               </h1>
//               <h2 className="notifications-title">
//                 Minhas notificações
//               </h2>
//             </div>

//             <div className="body-columns">

//               <div className="boletim-card">
//                 <h2 className="boletim-title">Boletim</h2>
//                 <GradesTable grades={grades} />
//               </div>

//               <div className="notifications-col">
//                 <div className="notifications-list">
//                   {notifications.length === 0 ? (
//                     <p>Nenhuma notificação encontrada.</p>
//                   ) : (
//                     notifications.map((notif) => (
//                       <NotifCard key={notif.idObservacao} notif={notif} />
//                     ))
//                   )}
//                 </div>
//               </div>

//             </div>
//           </>
//         )}

//       </div>
//     </div>
//   );
// }


// function GradesTable({ grades }) {
//   return (
//     <div className="grades-card">
//       <table className="grades-table">
//         <thead>
//           <tr>
//             <th>Disciplina ID</th>
//             <th>N1</th>
//             <th>N2</th>
//             <th>Média Final</th>
//           </tr>
//         </thead>
//         <tbody>
//           {grades.map((row) => (
//             <tr key={row.idBoletim}>
//               <td>{row.disciplinaId}</td>
//               <td>{row.nota1}</td>
//               <td>{row.nota2}</td>
//               <td>{row.media}</td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// }

// function NotifCard({ notif }) {

//   const formattedDate = new Date(notif.dataObs)
//     .toLocaleDateString("pt-BR");

//   return (
//     <div className="notif-card">
//       <div className="notif-avatar">
//         P
//       </div>

//       <div className="notif-body">
//         <div className="notif-name">
//           Professor #{notif.professorId}
//         </div>

//         <div className="notif-subtitle">
//           {formattedDate}
//         </div>

//         <div className="notif-text">
//           {notif.descricao}
//         </div>
//       </div>
//     </div>
//   );
// }