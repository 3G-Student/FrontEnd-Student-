import { useNavigate } from "react-router-dom";

export default function Sidebar() {
    const navigate = useNavigate();

  return (
    <aside className="sidebar">
        <div className="sidebar-perfil" onClick={() => navigate("/perfil")}>
          <div className="avatar-sidebar">J</div>
        </div>
      </aside>
  );
}
